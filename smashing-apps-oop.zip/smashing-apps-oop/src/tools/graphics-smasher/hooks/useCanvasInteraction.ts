import { useCallback, useRef, useState } from 'react';
import type Konva from 'konva';
import { useGraphicsStore } from '../state/graphicsStore';
import { useActiveDocument } from './useGraphicsStore';
import type { SelectionState } from '../types';

interface Point {
  x: number;
  y: number;
}

// Helper function to convert RGB to HSL
function rgbToHsl(r: number, g: number, b: number): string {
  r /= 255;
  g /= 255;
  b /= 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);

    switch (max) {
      case r:
        h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
        break;
      case g:
        h = ((b - r) / d + 2) / 6;
        break;
      case b:
        h = ((r - g) / d + 4) / 6;
        break;
    }
  }

  return `hsl(${Math.round(h * 360)}, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%)`;
}

// Helper function to check if a point is inside a polygon
function isPointInPolygon(x: number, y: number, polygonPoints: number[]): boolean {
  let inside = false;
  for (let i = 0, j = polygonPoints.length - 2; i < polygonPoints.length; i += 2) {
    const xi = polygonPoints[i];
    const yi = polygonPoints[i + 1];
    const xj = polygonPoints[j];
    const yj = polygonPoints[j + 1];

    const intersect = ((yi > y) !== (yj > y)) &&
      (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
    if (intersect) inside = !inside;

    j = i;
  }
  return inside;
}

export interface BrushStroke {
  tool: string;
  points: number[];
  color: string;
  size: number;
  opacity: number;
}

export interface Shape {
  type: 'rectangle' | 'ellipse' | 'line';
  x: number;
  y: number;
  width?: number;
  height?: number;
  fill?: string;
  stroke?: string;
  strokeWidth?: number;
  text?: string;
  font?: string;
  fontSize?: number;
  fontColor?: string;
  fontBold?: boolean;
  fontItalic?: boolean;
  fontUnderline?: boolean;
}

export function useCanvasInteraction() {
  const activeTool = useGraphicsStore((state) => state.activeTool);
  const activeDocument = useActiveDocument();
  const updateLayer = useGraphicsStore((state) => state.updateLayer);
  const updateLayerSilent = useGraphicsStore((state) => state.updateLayerSilent);
  const pushHistory = useGraphicsStore((state) => state.pushHistory);
  const toolOptions = useGraphicsStore((state) => state.toolOptions);
  const setSelection = useGraphicsStore((state) => state.setSelection);
  const clearSelection = useGraphicsStore((state) => state.clearSelection);
  const cropDocument = useGraphicsStore((state) => state.cropDocument);
  const canvasStage = useGraphicsStore((state) => state.canvasStage);
  const setToolOptions = useGraphicsStore((state) => state.setToolOptions);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentStroke, setCurrentStroke] = useState<BrushStroke | null>(null);
  const [currentShape, setCurrentShape] = useState<Shape | null>(null);
  const [selectionPreview, setSelectionPreview] = useState<SelectionState['shape'] | null>(null);
  const lastPointRef = useRef<Point | null>(null);
  const shapeStartRef = useRef<Point | null>(null);
  const selectionStartRef = useRef<Point | null>(null);
  const lassoPointsRef = useRef<number[]>([]);

  const getPointerPosition = useCallback((stage: Konva.Stage): Point | null => {
    const pos = stage.getPointerPosition();
    if (!pos || !activeDocument) return null;

    // Transform pointer position to canvas coordinates
    const transform = stage.getAbsoluteTransform().copy().invert();
    return transform.point(pos);
  }, [activeDocument]);

  const handleMouseDown = useCallback((e: Konva.KonvaEventObject<MouseEvent>) => {
    // Ignore right-click (button 2) and middle-click (button 1)
    if (e.evt.button !== 0) return;

    if (!activeDocument) return;

    const stage = e.target.getStage();
    if (!stage) return;

    const pos = getPointerPosition(stage);
    if (!pos) return;

    const brushSettings = toolOptions.brush;
    const eraserSettings = toolOptions.eraser;
    const shapeSettings = toolOptions.shape;

    switch (activeTool) {
      case 'move': {
        const selection = useGraphicsStore.getState().selection;
        if (selection) {
          selectionStartRef.current = pos;
          setIsDrawing(true);
          return;
        }
        return;
      }
      case 'hand':
        clearSelection();
        return;
      case 'eyedropper': {
        const stage = canvasStage;
        if (stage) {
          const canvas = stage.toCanvas();
          const ctx = canvas.getContext('2d');
          if (ctx) {
            const x = Math.floor(pos.x);
            const y = Math.floor(pos.y);

            // Ensure coordinates are within canvas bounds
            if (x >= 0 && x < canvas.width && y >= 0 && y < canvas.height) {
              const pixelData = ctx.getImageData(x, y, 1, 1).data;
              const r = pixelData[0];
              const g = pixelData[1];
              const b = pixelData[2];
              const a = pixelData[3] / 255;

              // Convert to hex color
              const hexColor = `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;

              // Update brush color
              setToolOptions('brush', { color: hexColor });

              // Log color in multiple formats for user reference
              console.log('Picked color:', {
                hex: hexColor,
                rgb: `rgb(${r}, ${g}, ${b})`,
                rgba: `rgba(${r}, ${g}, ${b}, ${a.toFixed(2)})`,
                hsl: rgbToHsl(r, g, b)
              });
            }
          }
        }
        setIsDrawing(false);
        return;
      }
      case 'paint-bucket': {
        if (canvasStage && activeDocument.activeLayerId) {
          const canvas = canvasStage.toCanvas();
          const ctx = canvas.getContext('2d');
          if (ctx) {
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const targetPixel = ctx.getImageData(pos.x, pos.y, 1, 1).data;
            const fillColor = brushSettings.color;
            
            // Convert hex to RGB
            const r = parseInt(fillColor.slice(1, 3), 16);
            const g = parseInt(fillColor.slice(3, 5), 16);
            const b = parseInt(fillColor.slice(5, 7), 16);
            
            // Simple flood fill (for small areas)
            const floodFill = (x: number, y: number) => {
              const stack: Point[] = [{ x, y }];
              const visited = new Set<string>();
              
              while (stack.length > 0) {
                const point = stack.pop()!;
                const key = `${point.x},${point.y}`;
                
                if (visited.has(key) || point.x < 0 || point.y < 0 ||
                    point.x >= canvas.width || point.y >= canvas.height) {
                  continue;
                }
                
                visited.add(key);
                const idx = (point.y * canvas.width + point.x) * 4;
                
                if (imageData.data[idx] === targetPixel[0] &&
                    imageData.data[idx + 1] === targetPixel[1] &&
                    imageData.data[idx + 2] === targetPixel[2] &&
                    imageData.data[idx + 3] === targetPixel[3]) {
                  imageData.data[idx] = r;
                  imageData.data[idx + 1] = g;
                  imageData.data[idx + 2] = b;
                  imageData.data[idx + 3] = 255;
                  
                  if (visited.size < 10000) { // Limit to prevent browser hang
                    stack.push({ x: point.x + 1, y: point.y });
                    stack.push({ x: point.x - 1, y: point.y });
                    stack.push({ x: point.x, y: point.y + 1 });
                    stack.push({ x: point.x, y: point.y - 1 });
                  }
                }
              }
            };
            
            floodFill(Math.floor(pos.x), Math.floor(pos.y));
            
            // Create a temporary canvas to store the filled image
            const tempCanvas = document.createElement('canvas');
            tempCanvas.width = canvas.width;
            tempCanvas.height = canvas.height;
            const tempCtx = tempCanvas.getContext('2d')!;
            tempCtx.putImageData(imageData, 0, 0);
            
            // Store as a shape/image in the layer
            const activeLayer = activeDocument.layers.find(l => l.id === activeDocument.activeLayerId);
            const existingShapes = (activeLayer?.metadata?.shapes as Shape[]) || [];
            
            updateLayer(activeDocument.id, activeDocument.activeLayerId, (layer) => ({
              ...layer,
              metadata: {
                ...layer.metadata,
                fillImageUrl: tempCanvas.toDataURL(),
                shapes: existingShapes
              }
            }));
          }
        }
        setIsDrawing(false);
        return;
      }
      case 'text': {
        const textSettings = toolOptions.text;
        const textContent = prompt('Enter text:');
        if (textContent && activeDocument.activeLayerId) {
          const activeLayer = activeDocument.layers.find(l => l.id === activeDocument.activeLayerId);
          const existingShapes = (activeLayer?.metadata?.shapes as Shape[]) || [];
          
          updateLayer(activeDocument.id, activeDocument.activeLayerId, (layer) => ({
            ...layer,
            metadata: {
              ...layer.metadata,
              shapes: [...existingShapes, {
                type: 'rectangle' as const,
                x: pos.x,
                y: pos.y,
                width: 0,
                height: 0,
                fill: 'transparent',
                stroke: 'transparent',
                strokeWidth: 0,
                text: textContent,
                font: textSettings.font,
                fontSize: textSettings.size,
                fontColor: textSettings.color,
                fontBold: textSettings.bold,
                fontItalic: textSettings.italic,
                fontUnderline: textSettings.underline
              }]
            }
          }));
        }
        setIsDrawing(false);
        return;
      }
      case 'magic-wand': {
        if (canvasStage && activeDocument.activeLayerId) {
          const canvas = canvasStage.toCanvas();
          const ctx = canvas.getContext('2d');
          if (ctx) {
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const clickedPixel = ctx.getImageData(Math.floor(pos.x), Math.floor(pos.y), 1, 1).data;
            const tolerance = toolOptions.selection.tolerance;

            const x = Math.floor(pos.x);
            const y = Math.floor(pos.y);

            // Ensure click is within canvas bounds
            if (x < 0 || x >= canvas.width || y < 0 || y >= canvas.height) {
              console.log('Magic wand: Click outside canvas bounds');
              setIsDrawing(false);
              return;
            }

            const selectedPoints: number[] = [];
            const visited = new Set<string>();
            const stack: Point[] = [{ x, y }];
            const maxPixels = 50000; // Limit to prevent performance issues

            const colorMatch = (px: number, py: number): boolean => {
              const idx = (py * canvas.width + px) * 4;
              const r = Math.abs(imageData.data[idx] - clickedPixel[0]);
              const g = Math.abs(imageData.data[idx + 1] - clickedPixel[1]);
              const b = Math.abs(imageData.data[idx + 2] - clickedPixel[2]);
              return r <= tolerance && g <= tolerance && b <= tolerance;
            };

            while (stack.length > 0 && visited.size < maxPixels) {
              const point = stack.pop()!;
              const key = `${point.x},${point.y}`;

              if (visited.has(key) || point.x < 0 || point.y < 0 ||
                  point.x >= canvas.width || point.y >= canvas.height) {
                continue;
              }

              if (!colorMatch(point.x, point.y)) {
                continue;
              }

              visited.add(key);
              selectedPoints.push(point.x, point.y);

              // Add adjacent pixels to stack
              stack.push({ x: point.x + 1, y: point.y });
              stack.push({ x: point.x - 1, y: point.y });
              stack.push({ x: point.x, y: point.y + 1 });
              stack.push({ x: point.x, y: point.y - 1 });
            }

            if (selectedPoints.length > 0) {
              // Calculate bounding box from selected pixels
              let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
              for (let i = 0; i < selectedPoints.length; i += 2) {
                const px = selectedPoints[i];
                const py = selectedPoints[i + 1];
                minX = Math.min(minX, px);
                minY = Math.min(minY, py);
                maxX = Math.max(maxX, px);
                maxY = Math.max(maxY, py);
              }

              // Create a rectangular selection from the bounding box
              setSelection({
                tool: 'magic-wand',
                shape: {
                  type: 'rect',
                  x: minX,
                  y: minY,
                  width: maxX - minX + 1,
                  height: maxY - minY + 1
                },
                layerId: activeDocument.activeLayerId
              });
              console.log(`Magic wand selected ${visited.size} pixels (tolerance: ${tolerance}), bounding box: ${minX},${minY} to ${maxX},${maxY}`);
              if (visited.size >= maxPixels) {
                console.warn(`Selection limited to ${maxPixels} pixels for performance`);
              }
            } else {
              console.log('Magic wand: No matching pixels found');
            }
          }
        }
        setIsDrawing(false);
        return;
      }
      default:
        break;
    }

    clearSelection();
    setIsDrawing(true);
    lastPointRef.current = pos;

    switch (activeTool) {
      case 'brush':
      case 'clone-stamp':
      case 'healing-brush':
        setCurrentStroke({
          tool: activeTool,
          points: [pos.x, pos.y],
          color: brushSettings.color,
          size: brushSettings.size,
          opacity: brushSettings.opacity
        });
        break;
      case 'eraser':
        setCurrentStroke({
          tool: 'eraser',
          points: [pos.x, pos.y],
          color: '#ffffff',
          size: eraserSettings.size,
          opacity: 1 // Always use full opacity for eraser to ensure complete removal
        });
        break;
      case 'shape':
        shapeStartRef.current = pos;
        setCurrentShape({
          type: 'rectangle',
          x: pos.x,
          y: pos.y,
          width: 0,
          height: 0,
          fill: shapeSettings.fill,
          stroke: shapeSettings.stroke,
          strokeWidth: shapeSettings.strokeWidth
        });
        break;
      case 'pen': {
        const penSettings = toolOptions.pen;
        setCurrentStroke({
          tool: 'pen',
          points: [pos.x, pos.y],
          color: penSettings.stroke,
          size: penSettings.strokeWidth,
          opacity: 1
        });
        break;
      }
      case 'marquee-rect':
      case 'crop':
      case 'marquee-ellipse':
        selectionStartRef.current = pos;
        setSelectionPreview({
          type: 'rect',
          x: pos.x,
          y: pos.y,
          width: 0,
          height: 0
        });
        break;
      case 'lasso-free':
      case 'lasso-poly':
      case 'lasso-magnetic':
        selectionStartRef.current = pos;
        lassoPointsRef.current = [pos.x, pos.y];
        setSelectionPreview({
          type: 'lasso',
          points: [pos.x, pos.y]
        });
        break;
      default:
        setIsDrawing(false);
        break;
    }
  }, [activeDocument, activeTool, getPointerPosition, toolOptions, updateLayer, clearSelection]);

  const handleMouseMove = useCallback((e: Konva.KonvaEventObject<MouseEvent>) => {
    if (!isDrawing || !activeDocument) return;

    const stage = e.target.getStage();
    if (!stage) return;

    const pos = getPointerPosition(stage);
    if (!pos) return;

    switch (activeTool) {
      case 'move': {
        const selection = useGraphicsStore.getState().selection;
        if (selection && selectionStartRef.current && selection.layerId) {
          const deltaX = pos.x - selectionStartRef.current.x;
          const deltaY = pos.y - selectionStartRef.current.y;

          // Move the actual layer content, not just the selection outline
          const { documents } = useGraphicsStore.getState();
          const document = documents.find(d => d.id === activeDocument.id);
          if (document) {
            const layer = document.layers.find(l => l.id === selection.layerId);
            if (layer) {
              const metadata = layer.metadata || {};
              const strokes = (metadata.strokes as any[]) || [];
              const shapes = (metadata.shapes as any[]) || [];

              // Move strokes within the selection
              const movedStrokes = strokes.map(stroke => {
                if (!stroke.points || stroke.points.length < 2) return stroke;

                // Check if stroke is within selection
                let isInSelection = false;
                if (selection.shape.type === 'rect') {
                  const shape = selection.shape;
                  for (let i = 0; i < stroke.points.length; i += 2) {
                    const x = stroke.points[i];
                    const y = stroke.points[i + 1];
                    if (x >= shape.x && x <= shape.x + shape.width &&
                        y >= shape.y && y <= shape.y + shape.height) {
                      isInSelection = true;
                      break;
                    }
                  }
                } else if (selection.shape.type === 'lasso') {
                  const shape = selection.shape;
                  for (let i = 0; i < stroke.points.length; i += 2) {
                    const x = stroke.points[i];
                    const y = stroke.points[i + 1];
                    if (isPointInPolygon(x, y, shape.points)) {
                      isInSelection = true;
                      break;
                    }
                  }
                }

                if (isInSelection) {
                  return {
                    ...stroke,
                    points: stroke.points.map((val: number, idx: number) =>
                      idx % 2 === 0 ? val + deltaX : val + deltaY
                    )
                  };
                }
                return stroke;
              });

              // Move shapes within the selection
              const movedShapes = shapes.map(shape => {
                const sx = shape.x || 0;
                const sy = shape.y || 0;

                let isInSelection = false;
                if (selection.shape.type === 'rect') {
                  const selShape = selection.shape;
                  isInSelection = !(sx < selShape.x || sx > selShape.x + selShape.width ||
                                   sy < selShape.y || sy > selShape.y + selShape.height);
                } else if (selection.shape.type === 'lasso') {
                  const selShape = selection.shape;
                  isInSelection = isPointInPolygon(sx, sy, selShape.points);
                }

                if (isInSelection) {
                  return {
                    ...shape,
                    x: sx + deltaX,
                    y: sy + deltaY
                  };
                }
                return shape;
              });

              updateLayer(activeDocument.id, selection.layerId, (l) => ({
                ...l,
                metadata: {
                  ...metadata,
                  strokes: movedStrokes,
                  shapes: movedShapes
                }
              }));
            }
          }

          // Also move the selection outline
          if (selection.shape.type === 'rect') {
            setSelection({
              ...selection,
              shape: {
                ...selection.shape,
                x: selection.shape.x + deltaX,
                y: selection.shape.y + deltaY
              }
            });
          } else if (selection.shape.type === 'lasso') {
            const movedPoints = selection.shape.points.map((val, idx) =>
              idx % 2 === 0 ? val + deltaX : val + deltaY
            );
            setSelection({
              ...selection,
              shape: {
                ...selection.shape,
                points: movedPoints
              }
            });
          }

          selectionStartRef.current = pos;
        }
        break;
      }
      case 'brush':
      case 'clone-stamp':
      case 'healing-brush':
      case 'eraser':
      case 'pen':
        if (currentStroke) {
          setCurrentStroke({
            ...currentStroke,
            points: [...currentStroke.points, pos.x, pos.y]
          });
        }
        break;
      case 'shape':
      case 'pen':
        if (shapeStartRef.current && currentShape) {
          const width = pos.x - shapeStartRef.current.x;
          const height = pos.y - shapeStartRef.current.y;
          setCurrentShape({
            ...currentShape,
            width,
            height
          });
        }
        break;
      case 'marquee-rect':
      case 'marquee-ellipse':
      case 'crop':
        if (selectionStartRef.current) {
          setSelectionPreview({
            type: 'rect',
            x: selectionStartRef.current.x,
            y: selectionStartRef.current.y,
            width: pos.x - selectionStartRef.current.x,
            height: pos.y - selectionStartRef.current.y
          });
        }
        break;
      case 'lasso-free':
      case 'lasso-poly':
      case 'lasso-magnetic':
        if (selectionStartRef.current) {
          lassoPointsRef.current = [...lassoPointsRef.current, pos.x, pos.y];
          setSelectionPreview({
            type: 'lasso',
            points: [...lassoPointsRef.current]
          });
        }
        break;
      default:
        break;
    }

    lastPointRef.current = pos;
  }, [isDrawing, activeDocument, activeTool, currentStroke, currentShape, getPointerPosition]);

  const handleMouseUp = useCallback(() => {
    if (!isDrawing) return;

    const lastPoint = lastPointRef.current;

    if (activeTool === 'move' && selectionStartRef.current) {
      selectionStartRef.current = null;
      setIsDrawing(false);
      return;
    }

    setIsDrawing(false);
    lastPointRef.current = null;
    shapeStartRef.current = null;

    if (selectionStartRef.current && selectionPreview && activeDocument) {
      if (selectionPreview.type === 'rect') {
        const start = selectionStartRef.current;
        const end = lastPoint ?? start;
        const rect = {
          x: Math.min(start.x, end.x),
          y: Math.min(start.y, end.y),
          width: Math.abs(end.x - start.x),
          height: Math.abs(end.y - start.y)
        };

        if (rect.width > 1 && rect.height > 1) {
          if (activeTool === 'crop') {
            cropDocument(activeDocument.id, rect);
          } else {
            setSelection({
              tool: activeTool === 'marquee-ellipse' ? 'marquee-rect' : (activeTool as SelectionState['tool']),
              shape: {
                type: 'rect',
                ...rect
              },
              layerId: activeDocument.activeLayerId
            });
          }
        }
      } else if (selectionPreview.type === 'lasso' && selectionPreview.points.length > 4 && activeDocument) {
        const points = [...selectionPreview.points];
        if (lastPoint) {
          points.push(lastPoint.x, lastPoint.y);
        }
        setSelection({
          tool: 'lasso-free',
          shape: {
            type: 'lasso',
            points
          },
          layerId: activeDocument.activeLayerId
        });
      }

      selectionStartRef.current = null;
      lassoPointsRef.current = [];
      setSelectionPreview(null);
    }

    // Commit the stroke to the active layer
    if (currentStroke && activeDocument && currentStroke.points.length > 2) {
      const activeLayerId = activeDocument.activeLayerId;
      if (activeLayerId) {
        const activeLayer = activeDocument.layers.find(l => l.id === activeLayerId);
        const existingStrokes = (activeLayer?.metadata?.strokes as BrushStroke[]) || [];

        updateLayer(activeDocument.id, activeLayerId, (layer) => ({
          ...layer,
          metadata: {
            ...layer.metadata,
            strokes: [...existingStrokes, currentStroke]
          }
        }));

        console.log('Stroke saved to layer:', currentStroke);
      }
      setCurrentStroke(null);
    } else {
      setCurrentStroke(null);
    }

    // Commit the shape to the active layer
    if (currentShape && activeDocument && (currentShape.width !== 0 || currentShape.height !== 0)) {
      const activeLayerId = activeDocument.activeLayerId;
      if (activeLayerId) {
        const activeLayer = activeDocument.layers.find(l => l.id === activeLayerId);
        const existingShapes = (activeLayer?.metadata?.shapes as Shape[]) || [];

        updateLayer(activeDocument.id, activeLayerId, (layer) => ({
          ...layer,
          metadata: {
            ...layer.metadata,
            shapes: [...existingShapes, currentShape]
          }
        }));

        console.log('Shape saved to layer:', currentShape);
      }
      setCurrentShape(null);
    } else {
      setCurrentShape(null);
    }
  }, [isDrawing, selectionPreview, activeDocument, currentStroke, currentShape, activeTool, cropDocument, setSelection, updateLayer]);

  const handleMouseLeave = useCallback(() => {
    if (isDrawing) {
      handleMouseUp();
    }
  }, [isDrawing, handleMouseUp]);

  return {
    isDrawing,
    currentStroke,
    currentShape,
    selectionPreview,
    handleMouseDown,
    handleMouseMove,
    handleMouseUp,
    handleMouseLeave
  };
}
