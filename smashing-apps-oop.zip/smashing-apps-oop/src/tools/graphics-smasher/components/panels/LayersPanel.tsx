import React from 'react';
import { Eye, EyeOff, Lock, Unlock, ChevronUp, ChevronDown, Plus } from 'lucide-react';
import { useActiveDocument } from '../../hooks/useGraphicsStore';
import { useGraphicsStore } from '../../state/graphicsStore';

const LayersPanel: React.FC = () => {
  const document = useActiveDocument();
  const {
    toggleLayerVisibility,
    toggleLayerLock,
    setActiveLayer,
    reorderLayer,
    addLayer
  } = useGraphicsStore((state) => ({
    toggleLayerVisibility: state.toggleLayerVisibility,
    toggleLayerLock: state.toggleLayerLock,
    setActiveLayer: state.setActiveLayer,
    reorderLayer: state.reorderLayer,
    addLayer: state.addLayer
  }));

  if (!document) {
    return (
      <div className="p-4 text-sm text-slate-500">
        Create a document to manage its layers.
      </div>
    );
  }

  const handleReorder = (layerId: string, direction: 1 | -1) => {
    const index = document.layers.findIndex((layer) => layer.id === layerId);
    if (index === -1) {
      return;
    }
    const targetIndex = index + direction;
    if (targetIndex < 0 || targetIndex >= document.layers.length) {
      return;
    }
    reorderLayer(document.id, layerId, targetIndex);
  };

  return (
    <div className="flex h-full flex-col bg-white">
      <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-3 py-2.5">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600">Layer Stack</h4>
        <button
          className="inline-flex items-center rounded-md border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-700 shadow-sm transition hover:border-indigo-400 hover:bg-indigo-50 hover:text-indigo-700"
          onClick={() => addLayer(document.id, { name: `Layer ${document.layers.length}` })}
        >
          <Plus size={14} className="mr-1" />
          New Layer
        </button>
      </div>
      <ul className="flex-1 divide-y divide-slate-100 overflow-y-auto">
        {[...document.layers].reverse().map((layer, index) => {
          const originalIndex = document.layers.length - 1 - index;
          const isActive = layer.id === document.activeLayerId;
          const isBackground = originalIndex === 0;
          return (
            <li
              key={layer.id}
              className={`group flex items-center justify-between gap-2 border-l-2 px-3 py-3 text-sm transition ${
                isActive
                  ? 'border-l-indigo-500 bg-gradient-to-r from-indigo-50 to-transparent'
                  : 'border-l-transparent hover:border-l-slate-300 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <button
                  className={`rounded p-1 transition ${
                    layer.visible
                      ? 'text-slate-600 hover:bg-slate-200 hover:text-slate-800'
                      : 'text-slate-400 hover:bg-slate-200 hover:text-slate-600'
                  }`}
                  onClick={() => toggleLayerVisibility(document.id, layer.id)}
                  aria-label={layer.visible ? 'Hide layer' : 'Show layer'}
                >
                  {layer.visible ? <Eye size={16} /> : <EyeOff size={16} />}
                </button>
                <button
                  className={`rounded p-1 transition ${
                    layer.locked
                      ? 'text-amber-600 hover:bg-amber-100'
                      : 'text-slate-400 hover:bg-slate-200 hover:text-slate-600'
                  }`}
                  onClick={() => toggleLayerLock(document.id, layer.id)}
                  aria-label={layer.locked ? 'Unlock layer' : 'Lock layer'}
                >
                  {layer.locked ? <Lock size={16} /> : <Unlock size={16} />}
                </button>
                <button
                  onClick={() => setActiveLayer(document.id, layer.id)}
                  className="flex-1 text-left"
                >
                  <p className={`font-semibold ${isActive ? 'text-indigo-700' : 'text-slate-800'}`}>
                    {layer.name}
                  </p>
                  <p className="text-xs font-medium uppercase tracking-wider text-slate-400">
                    {layer.kind}
                  </p>
                </button>
              </div>
              <div className="flex items-center gap-1 opacity-0 transition group-hover:opacity-100">
                {!isBackground && (
                  <>
                    <button
                      className="rounded border border-slate-200 bg-white p-1 text-slate-500 shadow-sm transition hover:border-indigo-300 hover:bg-indigo-50 hover:text-indigo-700"
                      onClick={() => handleReorder(layer.id, 1)}
                      title="Move up"
                    >
                      <ChevronUp size={14} />
                    </button>
                    <button
                      className="rounded border border-slate-200 bg-white p-1 text-slate-500 shadow-sm transition hover:border-indigo-300 hover:bg-indigo-50 hover:text-indigo-700"
                      onClick={() => handleReorder(layer.id, -1)}
                      title="Move down"
                    >
                      <ChevronDown size={14} />
                    </button>
                  </>
                )}
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default LayersPanel;
