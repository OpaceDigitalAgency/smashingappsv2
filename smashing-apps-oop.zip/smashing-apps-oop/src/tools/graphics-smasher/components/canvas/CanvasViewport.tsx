import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type Konva from 'konva';
import { Stage, Layer as KonvaLayer, Rect, Group, Text, Line, Image as KonvaImage, Ellipse } from 'react-konva';
import { useActiveDocument } from '../../hooks/useGraphicsStore';
import { useGraphicsStore } from '../../state/graphicsStore';
import { useCanvasInteraction, type BrushStroke, type Shape } from '../../hooks/useCanvasInteraction';
import type { SelectionState } from '../../types';
import useImage from 'use-image';
import ContextMenu from '../overlays/ContextMenu';

// Move BackgroundLayer outside to avoid hooks issues
const BackgroundLayer: React.FC<{ layer: any; docWidth: number; docHeight: number; docBg: string }> = ({ layer, docWidth, docHeight, docBg }) => {
  const imageUrl = layer.metadata?.imageUrl as string | undefined;
  const [image] = useImage(imageUrl || '');

  if (imageUrl && image) {
    return (
      <KonvaImage
        key={layer.id}
        x={0}
        y={0}
        width={docWidth}
        height={docHeight}
        image={image}
        listening={false}
      />
    );
  }

  return (
    <Rect
      key={layer.id}
      x={0}
      y={0}
      width={docWidth}
      height={docHeight}
      fill={(layer.metadata?.fill as string) ?? docBg}
      listening={false}
    />
  );
};

const CanvasViewport: React.FC = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const stageRef = useRef<Konva.Stage | null>(null);
  const activeDocument = useActiveDocument();
  const setViewport = useGraphicsStore((state) => state.setViewport);
  const settings = useGraphicsStore((state) => state.settings);
  const activeTool = useGraphicsStore((state) => state.activeTool);
  const updateLayer = useGraphicsStore((state) => state.updateLayer);
  const selection = useGraphicsStore((state) => state.selection);
  const setCanvasStage = useGraphicsStore((state) => state.setCanvasStage);
  const [size, setSize] = useState({ width: 0, height: 0 });
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number } | null>(null);
  const [isPanning, setIsPanning] = useState(false);
  const [dashOffset, setDashOffset] = useState(0);

  const {
    isDrawing,
    currentStroke,
    currentShape,
    selectionPreview,
    handleMouseDown,
    handleMouseMove,
    handleMouseUp,
    handleMouseLeave
  } = useCanvasInteraction();

  useEffect(() => {
    const node = containerRef.current;
    if (!node) {
      return;
    }

    const updateSize = () => {
      const { clientWidth, clientHeight } = node;
      setSize({ width: clientWidth, height: clientHeight });
    };

    updateSize();
    const observer = new ResizeObserver(updateSize);
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  // Center canvas on initial load or when document changes
  useEffect(() => {
    if (!activeDocument || size.width === 0 || size.height === 0) {
      return;
    }

    // Only center if viewport is at default position (0, 0, zoom 1)
    const isDefaultViewport =
      activeDocument.viewport.panX === 0 &&
      activeDocument.viewport.panY === 0 &&
      activeDocument.viewport.zoom === 1;

    if (isDefaultViewport) {
      // Calculate zoom to fit canvas in viewport with some padding
      const padding = 100;
      const availableWidth = size.width - padding * 2;
      const availableHeight = size.height - padding * 2;

      const scaleX = availableWidth / activeDocument.width;
      const scaleY = availableHeight / activeDocument.height;
      const fitZoom = Math.min(scaleX, scaleY, 1); // Don't zoom in beyond 100%

      // Center the canvas
      const canvasWidth = activeDocument.width * fitZoom;
      const canvasHeight = activeDocument.height * fitZoom;
      const panX = (size.width - canvasWidth) / 2;
      const panY = (size.height - canvasHeight) / 2;

      setViewport(activeDocument.id, {
        zoom: fitZoom,
        panX,
        panY
      });
    }
  }, [activeDocument?.id, size.width, size.height]);

  // Marching ants animation
  useEffect(() => {
    let animationId: number;
    const animate = () => {
      setDashOffset((prev) => (prev + 0.5) % 12);
      animationId = requestAnimationFrame(animate);
    };
    animationId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationId);
  }, []);

  const handleWheel = useCallback(
    (event: any) => {
      if (!activeDocument) {
        return;
      }
      event.evt.preventDefault();

      const scaleBy = 1.05;
      const oldScale = activeDocument.viewport.zoom;
      const pointer = event.target.getStage().getPointerPosition();
      if (!pointer) {
        return;
      }

      const mousePointTo = {
        x: (pointer.x - activeDocument.viewport.panX) / oldScale,
        y: (pointer.y - activeDocument.viewport.panY) / oldScale
      };

      const direction = event.evt.deltaY > 0 ? -1 : 1;
      const newScale = direction > 0 ? oldScale * scaleBy : oldScale / scaleBy;
      const clampedScale = Math.min(Math.max(newScale, 0.2), 8);

      const newPos = {
        panX: pointer.x - mousePointTo.x * clampedScale,
        panY: pointer.y - mousePointTo.y * clampedScale
      };

      setViewport(activeDocument.id, {
        zoom: clampedScale,
        panX: newPos.panX,
        panY: newPos.panY
      });
    },
    [activeDocument, setViewport]
  );

  const handleContextMenu = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    setContextMenu({ x: e.clientX, y: e.clientY });
  }, []);

  const selectionStrokeWidth = useMemo(() => Math.max(1 / (activeDocument?.viewport.zoom ?? 1), 0.5), [activeDocument?.viewport.zoom]);

  const renderSelectionOverlay = useCallback(
    (shape: SelectionState['shape'], isPreview = false) => {
      if (!shape) {
        return null;
      }

      if (shape.type === 'rect') {
        const width = Math.abs(shape.width);
        const height = Math.abs(shape.height);
        if (width < 1 || height < 1) {
          return null;
        }

        const x = shape.width >= 0 ? shape.x : shape.x + shape.width;
        const y = shape.height >= 0 ? shape.y : shape.y + shape.height;

        return (
          <>
            <Rect
              x={x}
              y={y}
              width={width}
              height={height}
              stroke="#6366f1"
              dash={[8, 4]}
              dashOffset={dashOffset}
              strokeWidth={selectionStrokeWidth}
              listening={false}
            />
            <Rect
              x={x}
              y={y}
              width={width}
              height={height}
              fill={isPreview ? 'rgba(99,102,241,0.18)' : 'rgba(99,102,241,0.12)'}
              listening={false}
              opacity={isPreview ? 0.6 : 0.4}
            />
          </>
        );
      }

      if (shape.type === 'lasso') {
        if (shape.points.length < 4) {
          return null;
        }

        return (
          <Line
            points={shape.points}
            stroke="#6366f1"
            strokeWidth={selectionStrokeWidth}
            dash={[8, 4]}
            dashOffset={dashOffset}
            closed
            listening={false}
            fill={isPreview ? 'rgba(99,102,241,0.18)' : 'rgba(99,102,241,0.12)'}
            opacity={isPreview ? 0.6 : 0.4}
          />
        );
      }

      return null;
    },
    [selectionStrokeWidth, dashOffset]
  );

  const stageCursor = useMemo(() => {
    switch (activeTool) {
      case 'hand':
        return isPanning ? 'grabbing' : 'grab';
      case 'move':
        return 'move';
      case 'zoom':
        return 'zoom-in';
      case 'paint-bucket':
        return 'cell';
      case 'eyedropper':
        return 'crosshair';
      case 'brush':
      case 'clone-stamp':
      case 'healing-brush':
      case 'eraser':
      case 'shape':
      case 'pen':
      case 'marquee-rect':
      case 'marquee-ellipse':
      case 'lasso-free':
      case 'lasso-poly':
      case 'lasso-magnetic':
      case 'magic-wand':
      case 'object-select':
      case 'crop':
        return 'crosshair';
      default:
        return 'default';
    }
  }, [activeTool, isPanning]);

  const renderLayers = useMemo(() => {
    if (!activeDocument) {
      return null;
    }

    return activeDocument.layers.map((layer, index) => {
      const isBackground = index === 0;
      if (isBackground) {
        return (
          <BackgroundLayer
            key={layer.id}
            layer={layer}
            docWidth={activeDocument.width}
            docHeight={activeDocument.height}
            docBg={activeDocument.background}
          />
        );
      }

      const savedStrokes = (layer.metadata?.strokes as BrushStroke[]) || [];
      const savedShapes = (layer.metadata?.shapes as Shape[]) || [];
      const layerFill = layer.metadata?.fill as string | undefined;
      const hasContent = savedStrokes.length > 0 || savedShapes.length > 0 || layerFill;

      return (
        <Group
          key={layer.id}
          opacity={layer.opacity}
          visible={layer.visible}
          listening={false}
        >
          {layerFill && (
            <Rect
              width={activeDocument.width}
              height={activeDocument.height}
              fill={layerFill}
              listening={false}
            />
          )}

          {layer.metadata?.fillImageUrl && (() => {
            const img = new window.Image();
            img.src = layer.metadata.fillImageUrl as string;
            return (
              <KonvaImage
                image={img}
                x={0}
                y={0}
                width={activeDocument.width}
                height={activeDocument.height}
                listening={false}
              />
            );
          })()}

          {savedStrokes.map((stroke, strokeIndex) => (
            <Line
              key={`stroke-${layer.id}-${strokeIndex}`}
              points={stroke.points}
              stroke={stroke.color}
              strokeWidth={stroke.size}
              opacity={stroke.opacity}
              tension={0.5}
              lineCap="round"
              lineJoin="round"
              listening={activeTool === 'move' || activeTool === 'object-select'}
              onClick={() => {
                if (activeTool === 'move' || activeTool === 'object-select') {
                  console.log('Selected stroke:', strokeIndex);
                }
              }}
              globalCompositeOperation={stroke.tool === 'eraser' ? 'destination-out' : 'source-over'}
            />
          ))}

          {savedShapes.map((shape, shapeIndex) => {
            if ((shape as any).text) {
              const fontStyle = `${(shape as any).fontBold ? 'bold ' : ''}${(shape as any).fontItalic ? 'italic ' : ''}${(shape as any).fontSize || 16}px ${(shape as any).font || 'Arial'}`;
              return (
                <Text
                  key={`text-${layer.id}-${shapeIndex}`}
                  x={shape.x}
                  y={shape.y}
                  text={(shape as any).text}
                  fontSize={(shape as any).fontSize || 16}
                  fontFamily={(shape as any).font || 'Arial'}
                  fontStyle={(shape as any).fontBold ? 'bold' : (shape as any).fontItalic ? 'italic' : 'normal'}
                  textDecoration={(shape as any).fontUnderline ? 'underline' : ''}
                  fill={(shape as any).fontColor || '#000000'}
                  listening={activeTool === 'move' || activeTool === 'object-select'}
                  onClick={() => {
                    if (activeTool === 'move' || activeTool === 'object-select') {
                      console.log('Selected text:', shapeIndex);
                    }
                  }}
                />
              );
            }
            if (shape.type === 'rectangle' && shape.width && shape.height) {
              const isEraser = (shape as any).isEraser === true;
              return (
                <Rect
                  key={`shape-${layer.id}-${shapeIndex}`}
                  x={shape.x}
                  y={shape.y}
                  width={shape.width}
                  height={shape.height}
                  fill={shape.fill || 'transparent'}
                  stroke={shape.stroke || '#000000'}
                  strokeWidth={shape.strokeWidth || 1}
                  listening={activeTool === 'move' || activeTool === 'object-select'}
                  globalCompositeOperation={isEraser ? 'destination-out' : 'source-over'}
                  onClick={() => {
                    if (activeTool === 'move' || activeTool === 'object-select') {
                      console.log('Selected shape:', shapeIndex);
                    }
                  }}
                />
              );
            }
            if (shape.type === 'ellipse' && shape.width && shape.height) {
              return (
                <Ellipse
                  key={`shape-${layer.id}-${shapeIndex}`}
                  x={shape.x + shape.width / 2}
                  y={shape.y + shape.height / 2}
                  radiusX={Math.abs(shape.width) / 2}
                  radiusY={Math.abs(shape.height) / 2}
                  fill={shape.fill || 'transparent'}
                  stroke={shape.stroke || '#000000'}
                  strokeWidth={shape.strokeWidth || 1}
                  listening={activeTool === 'move' || activeTool === 'object-select'}
                  onClick={() => {
                    if (activeTool === 'move' || activeTool === 'object-select') {
                      console.log('Selected shape:', shapeIndex);
                    }
                  }}
                />
              );
            }
            if ((shape as any).type === 'polygon' && (shape as any).points) {
              const isEraser = (shape as any).isEraser === true;
              return (
                <Line
                  key={`shape-${layer.id}-${shapeIndex}`}
                  points={(shape as any).points}
                  fill={(shape as any).fill || 'transparent'}
                  stroke={(shape as any).stroke || 'transparent'}
                  strokeWidth={(shape as any).strokeWidth || 0}
                  closed
                  listening={false}
                  globalCompositeOperation={isEraser ? 'destination-out' : 'source-over'}
                />
              );
            }
            return null;
          })}

          {!hasContent && (
            <>
              <Rect
                width={activeDocument.width * 0.4}
                height={activeDocument.height * 0.4}
                fill="rgba(99,102,241,0.12)"
                stroke="rgba(79,70,229,0.8)"
                dash={[6, 6]}
                cornerRadius={12}
                listening={false}
              />
              <Text
                text={layer.name}
                fontSize={16}
                fill="#1f2937"
                padding={12}
                listening={false}
              />
            </>
          )}
        </Group>
      );
    });
  }, [activeDocument, activeTool, updateLayer]);

  if (!activeDocument) {
    return null;
  }

  useEffect(() => {
    return () => {
      setCanvasStage(null);
    };
  }, [setCanvasStage]);

  return (
    <div
      ref={containerRef}
      className="relative h-full w-full overflow-hidden bg-gradient-to-br from-slate-200 via-slate-100 to-slate-200"
      onContextMenu={handleContextMenu}
    >
      {/* Zoom indicator */}
      <div className="absolute left-4 top-4 z-10 flex items-center gap-2 rounded-lg border border-slate-300 bg-white/90 px-3 py-1.5 text-xs font-semibold text-slate-700 shadow-lg backdrop-blur-sm">
        <span>{Math.round(activeDocument.viewport.zoom * 100)}%</span>
        <div className="h-3 w-px bg-slate-300" />
        <button
          onClick={() => setViewport(activeDocument.id, { zoom: Math.max(0.2, activeDocument.viewport.zoom - 0.1) })}
          className="text-slate-500 hover:text-slate-700"
          title="Zoom out"
        >
          −
        </button>
        <button
          onClick={() => setViewport(activeDocument.id, { zoom: Math.min(8, activeDocument.viewport.zoom + 0.1) })}
          className="text-slate-500 hover:text-slate-700"
          title="Zoom in"
        >
          +
        </button>
      </div>

      {/* Canvas stage */}
      <Stage
        ref={(node) => {
          stageRef.current = node;
          setCanvasStage(node ?? null);
        }}
        width={size.width}
        height={size.height}
        scaleX={activeDocument.viewport.zoom}
        scaleY={activeDocument.viewport.zoom}
        x={activeDocument.viewport.panX}
        y={activeDocument.viewport.panY}
        draggable={activeTool === 'hand'}
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseLeave}
        onDragStart={() => setIsPanning(true)}
        onDragEnd={(event) => {
          setIsPanning(false);
          if (!activeDocument) {
            return;
          }
          const node = event.target as Konva.Stage;
          setViewport(activeDocument.id, {
            panX: node.x(),
            panY: node.y()
          });
        }}
        style={{ cursor: stageCursor }}
      >
        <KonvaLayer listening={false}>
          <Rect
            x={-4000}
            y={-4000}
            width={8000}
            height={8000}
            fillPatternImage={undefined}
            fill="#f1f5f9"
          />
        </KonvaLayer>
        <KonvaLayer>
          {/* Document boundary with shadow */}
          <Rect
            x={-5}
            y={-5}
            width={activeDocument.width + 10}
            height={activeDocument.height + 10}
            fill="rgba(0,0,0,0.1)"
            shadowBlur={20}
            shadowColor="rgba(0,0,0,0.3)"
            shadowOffsetX={0}
            shadowOffsetY={4}
          />
          <Group>
            {renderLayers}

            {currentStroke && (
              <Line
                points={currentStroke.points}
                stroke={currentStroke.color}
                strokeWidth={currentStroke.size}
                opacity={currentStroke.opacity}
                tension={0.5}
                lineCap="round"
                lineJoin="round"
                listening={false}
                globalCompositeOperation={currentStroke.tool === 'eraser' ? 'destination-out' : 'source-over'}
              />
            )}

            {currentShape && currentShape.type === 'rectangle' && (
              <Rect
                x={currentShape.x}
                y={currentShape.y}
                width={currentShape.width || 0}
                height={currentShape.height || 0}
                fill={currentShape.fill}
                stroke={currentShape.stroke}
                strokeWidth={currentShape.strokeWidth}
                listening={false}
              />
            )}
            {currentShape && currentShape.type === 'ellipse' && (
              <Ellipse
                x={currentShape.x + (currentShape.width || 0) / 2}
                y={currentShape.y + (currentShape.height || 0) / 2}
                radiusX={Math.abs((currentShape.width || 0) / 2)}
                radiusY={Math.abs((currentShape.height || 0) / 2)}
                fill={currentShape.fill}
                stroke={currentShape.stroke}
                strokeWidth={currentShape.strokeWidth}
                listening={false}
              />
            )}

            {selectionPreview && renderSelectionOverlay(selectionPreview, true)}
            {selection?.shape && renderSelectionOverlay(selection.shape, false)}
          </Group>
        </KonvaLayer>
      </Stage>

      {/* Grid overlay */}
      {settings.snapToGrid && activeDocument.viewport.showGrid && (
        <div
          className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_right,rgba(99,102,241,0.08)_1px,transparent_1px),linear-gradient(to_bottom,rgba(99,102,241,0.08)_1px,transparent_1px)]"
          style={{
            backgroundSize: `${(activeDocument.viewport.gridSize ?? 32) * activeDocument.viewport.zoom}px ${(activeDocument.viewport.gridSize ?? 32) * activeDocument.viewport.zoom}px`
          }}
        />
      )}

      {/* Guides overlay */}
      {settings.snapToGuides && activeDocument.viewport.showGuides && (
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute left-1/2 top-0 h-full w-px bg-indigo-400/50 shadow-sm"></div>
          <div className="absolute left-0 top-1/2 w-full border-t border-indigo-400/50 shadow-sm"></div>
        </div>
      )}

      {/* Rulers (placeholder) */}
      {activeDocument.viewport.showRulers && (
        <>
          <div className="pointer-events-none absolute left-0 top-0 h-6 w-full border-b border-slate-300 bg-white/80 backdrop-blur-sm" />
          <div className="pointer-events-none absolute left-0 top-0 h-full w-6 border-r border-slate-300 bg-white/80 backdrop-blur-sm" />
        </>
      )}

      {/* Context Menu */}
      {contextMenu && (
        <ContextMenu
          x={contextMenu.x}
          y={contextMenu.y}
          onClose={() => setContextMenu(null)}
        />
      )}
    </div>
  );
};

export default CanvasViewport;
