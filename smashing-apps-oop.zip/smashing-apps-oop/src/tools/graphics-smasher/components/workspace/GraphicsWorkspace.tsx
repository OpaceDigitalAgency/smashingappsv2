import React, { useEffect, useMemo, useState } from 'react';
import MenuBar from '../menus/MenuBar';
import DocumentTabs from './DocumentTabs';
import ProfessionalToolbar from '../toolbar/ProfessionalToolbar';
import ToolOptionsBar from '../toolbar/ToolOptionsBar';
import CanvasViewport from '../canvas/CanvasViewport';
import PanelTabs from '../panels/PanelTabs';
import LayersPanel from '../panels/LayersPanel';
import AdjustmentsPanel from '../panels/AdjustmentsPanel';
import HistoryPanel from '../panels/HistoryPanel';
import PropertiesPanel from '../panels/PropertiesPanel';
import AssetsPanel from '../panels/AssetsPanel';
import CommandPaletteOverlay from '../overlays/CommandPaletteOverlay';
import KeyboardShortcutsModal from '../dialogs/KeyboardShortcutsModal';
import AboutModal from '../dialogs/AboutModal';
import { useActiveDocument, useActiveDocumentId } from '../../hooks/useGraphicsStore';
import { useGraphicsStore } from '../../state/graphicsStore';
import { useGraphicsShortcuts } from '../../hooks/useGraphicsShortcuts';
import { useCanvasEngineBootstrap } from '../../services/rendering/canvasEngine';
import { useImageWorkerBootstrap } from '../../services/workers/workerBridge';

const GraphicsWorkspace: React.FC = () => {
  const activePanel = useGraphicsStore((state) => state.activePanel);
  const activeDocument = useActiveDocument();
  const activeDocumentId = useActiveDocumentId();
  const engineStatus = useGraphicsStore((state) => state.canvasEngine);
  const activeTool = useGraphicsStore((state) => state.activeTool);
  const documents = useGraphicsStore((state) => state.documents);
  const createDocument = useGraphicsStore((state) => state.createDocument);
  const setActiveDocument = useGraphicsStore((state) => state.setActiveDocument);
  const keyboardShortcutsModalOpen = useGraphicsStore((state) => state.keyboardShortcutsModalOpen);
  const setKeyboardShortcutsModalOpen = useGraphicsStore((state) => state.setKeyboardShortcutsModalOpen);
  const aboutModalOpen = useGraphicsStore((state) => state.aboutModalOpen);
  const setAboutModalOpen = useGraphicsStore((state) => state.setAboutModalOpen);
  const [topOffset, setTopOffset] = useState(0);

  useGraphicsShortcuts(activeDocumentId);
  useCanvasEngineBootstrap();
  useImageWorkerBootstrap();

  // Auto-create a default document on first load
  useEffect(() => {
    if (documents.length === 0) {
      const docId = createDocument({
        name: 'Untitled',
        width: 1920,
        height: 1080,
        background: '#ffffff'
      });
      setActiveDocument(docId);
    }
  }, []);

  const panelContent = useMemo(() => {
    switch (activePanel) {
      case 'layers':
        return <LayersPanel />;
      case 'adjustments':
        return <AdjustmentsPanel />;
      case 'history':
        return <HistoryPanel />;
      case 'properties':
        return <PropertiesPanel />;
      case 'assets':
        return <AssetsPanel />;
      default:
        return null;
    }
  }, [activePanel]);

  const isDarkMode = useGraphicsStore((state) => {
    const saved = localStorage.getItem('graphics-smasher-theme');
    return saved ? saved === 'dark' : true;
  });

  useEffect(() => {
    const updateOffset = () => {
      const main = document.querySelector('[data-layout-main]');
      if (!main) {
        setTopOffset(0);
        return;
      }
      const rect = (main as HTMLElement).getBoundingClientRect();
      setTopOffset(rect.top);
    };

    updateOffset();

    const main = document.querySelector('[data-layout-main]');
    if (main) {
      const observer = new ResizeObserver(updateOffset);
      observer.observe(main);
      window.addEventListener('resize', updateOffset);
      return () => {
        observer.disconnect();
        window.removeEventListener('resize', updateOffset);
      };
    }

    window.addEventListener('resize', updateOffset);
    return () => {
      window.removeEventListener('resize', updateOffset);
    };
  }, []);

  return (
    <div
      className="fixed inset-x-0 bottom-0 flex flex-col bg-slate-50 overflow-hidden"
      style={{ top: topOffset }}
    >
      <style>{`
        .graphics-smasher-container.dark-theme {
          background: #1a1a1a;
          color: #e0e0e0;
        }
        .graphics-smasher-container.dark-theme .bg-white {
          background: #2a2a2a !important;
        }
        .graphics-smasher-container.dark-theme .bg-slate-50 {
          background: #1e1e1e !important;
        }
        .graphics-smasher-container.dark-theme .bg-slate-100 {
          background: #252525 !important;
        }
        .graphics-smasher-container.dark-theme .bg-slate-200 {
          background: #2d2d2d !important;
        }
        .graphics-smasher-container.dark-theme .text-slate-700 {
          color: #d0d0d0 !important;
        }
        .graphics-smasher-container.dark-theme .text-slate-600 {
          color: #b0b0b0 !important;
        }
        .graphics-smasher-container.dark-theme .text-slate-500 {
          color: #909090 !important;
        }
        .graphics-smasher-container.dark-theme .border-slate-200 {
          border-color: #3a3a3a !important;
        }
        .graphics-smasher-container.dark-theme .border-slate-300 {
          border-color: #4a4a4a !important;
        }
        .graphics-smasher-container.dark-theme .shadow-sm,
        .graphics-smasher-container.dark-theme .shadow-md,
        .graphics-smasher-container.dark-theme .shadow-lg {
          box-shadow: 0 0 0 1px rgba(255,255,255,0.05) !important;
        }
        .graphics-smasher-container.dark-theme .hover\\:bg-slate-100:hover {
          background: #303030 !important;
        }
        .graphics-smasher-container.dark-theme .hover\\:bg-slate-50:hover {
          background: #282828 !important;
        }
        .graphics-smasher-container.dark-theme .bg-gradient-to-b {
          background: linear-gradient(to bottom, #2a2a2a, #222222) !important;
        }
        .graphics-smasher-container.dark-theme .bg-gradient-to-r {
          background: linear-gradient(to right, #2a2a2a, #222222) !important;
        }
        .graphics-smasher-container.dark-theme .bg-gradient-to-br {
          background: linear-gradient(to bottom right, #2d2d2d, #252525, #2d2d2d) !important;
        }
        .graphics-smasher-container.light-theme {
          background: #f8fafc;
          color: #1e293b;
        }
        .main-nav-dark {
          background: #2a2a2a !important;
          border-color: #3a3a3a !important;
        }
        .main-nav-dark a,
        .main-nav-dark button {
          color: #e0e0e0 !important;
        }
        .main-nav-dark img {
          filter: brightness(0) invert(1);
        }
      `}</style>

      {/* Graphics Smasher Workspace */}
      <div className={`graphics-smasher-container flex flex-col flex-1 overflow-hidden ${isDarkMode ? 'dark-theme' : 'light-theme'}`}>
        <MenuBar />
        <ToolOptionsBar />
        <DocumentTabs />
        <div className="flex flex-1 overflow-hidden min-h-0">
          <ProfessionalToolbar />
          <div className="flex flex-1 flex-col min-w-0">
            <div className="flex flex-1 overflow-hidden min-h-0">
              <div className="relative flex flex-1 bg-slate-200 min-w-0">
                <CanvasViewport key={activeDocumentId || 'no-doc'} />
              </div>
              <aside className="flex w-80 flex-shrink-0 flex-col border-l border-slate-200 bg-white shadow-lg overflow-hidden">
                <PanelTabs />
                <div className="flex-1 overflow-y-auto min-h-0">{panelContent}</div>
              </aside>
            </div>
            <footer className="flex items-center justify-between border-t border-slate-200 bg-white px-4 py-1.5 text-xs text-slate-500 shadow-inner flex-shrink-0">
              {activeDocument && (
                <>
                  <span className="font-medium">
                    {activeDocument.name} • {activeDocument.width}×{activeDocument.height}px •{' '}
                    {activeDocument.layers.length} layers
                  </span>
                  <span>
                    GPU:{' '}
                    {engineStatus.webgpuAvailable
                      ? 'WebGPU ready'
                      : engineStatus.webglAvailable
                        ? 'WebGL ready'
                        : 'Canvas 2D'}{' '}
                    • Tool: {activeTool.toUpperCase()}
                  </span>
                </>
              )}
            </footer>
          </div>
        </div>
        <CommandPaletteOverlay />
        {keyboardShortcutsModalOpen && (
          <KeyboardShortcutsModal onClose={() => setKeyboardShortcutsModalOpen(false)} />
        )}
        {aboutModalOpen && (
          <AboutModal onClose={() => setAboutModalOpen(false)} />
        )}
      </div>
    </div>
  );
};

export default GraphicsWorkspace;
